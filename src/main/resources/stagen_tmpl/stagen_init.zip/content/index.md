# From index.md

This content is from _index.md_. This is a [link](other.html) to the _other_ page.
