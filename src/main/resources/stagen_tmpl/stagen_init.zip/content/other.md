# Content is from other.md.

This content is from _other.md_. This content does not have a custom template (no _other.st_&mdash;so uses the _index.st_ template), but has custom configuration _other.json_ (check the custom page title).
