WizTools.org StaGen static site generator configured directory.

This file is for information purposes, and may be deleted.

